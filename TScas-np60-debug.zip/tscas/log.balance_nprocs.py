number of processors is 60
Setting number of processors configuration to [10, 6, 1]
