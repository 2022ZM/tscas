#!/bin/sh

rm -r ./constant/polyMesh


surfaceFeatureExtract
blockMesh
decomposePar -force
mpirun --oversubscribe  -np 8 snappyHexMesh -parallel -overwrite | tee log.sn
reconstructParMesh  -constant
reconstructPar  -constant
renumberMesh -overwrite
checkMesh
